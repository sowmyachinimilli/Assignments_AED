/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Person;



/**
 *
 * @author sowmyachinimilli
 */
public class Profile {
    private String Name;
    private String GeographicData;
    private String DateOfBirth;
    private long PhoneNumber;
    private int FaxNumber;
    private String EmailAddress;
    private int SSN;
    private int MedicalRecordNum;
    private String HealthPlanBenifNum;
    private long BankAccNum;
    private String LicenseNum;
    private String VehicleIdentifiersAndSerialNumbersIncludingLicensePlates;
    private String DeviceIdentifiersAndSerialNumbers;
    private String LinkedIn;
    private String InternetProtocolAddress;
    private String BiometricIdentfiers; //(i.e. retinal scan, fingerprints)
    private String Photo; //Full face photos and comparable images
    private String Unique_ID_Char_Code;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getGeographicData() {
        return GeographicData;
    }

    public void setGeographicData(String GeographicData) {
        this.GeographicData = GeographicData;
    }

    public long getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(long PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public int getFaxNumber() {
        return FaxNumber;
    }

    public void setFaxNumber(int FaxNumber) {
        this.FaxNumber = FaxNumber;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String EmailAddress) {
        this.EmailAddress = EmailAddress;
    }

    public int getSSN() {
        return SSN;
    }

    public void setSSN(int SSN) {
        this.SSN = SSN;
    }

    public int getMedicalRecordNum() {
        return MedicalRecordNum;
    }

    public void setMedicalRecordNum(int MedicalRecordNum) {
        this.MedicalRecordNum = MedicalRecordNum;
    }

    public String getHealthPlanBenifNum() {
        return HealthPlanBenifNum;
    }

    public void setHealthPlanBenifNum(String HealthPlanBenifNum) {
        this.HealthPlanBenifNum = HealthPlanBenifNum;
    }

    public long getBankAccNum() {
        return BankAccNum;
    }

    public void setBankAccNum(long BankAccNum) {
        this.BankAccNum = BankAccNum;
    }

    public String getLicenseNum() {
        return LicenseNum;
    }

    public void setLicenseNum(String LicenseNum) {
        this.LicenseNum = LicenseNum;
    }

    public String getVehicleIdentifiersAndSerialNumbersIncludingLicensePlates() {
        return VehicleIdentifiersAndSerialNumbersIncludingLicensePlates;
    }

    public void setVehicleIdentifiersAndSerialNumbersIncludingLicensePlates(String VehicleIdentifiersAndSerialNumbersIncludingLicensePlates) {
        this.VehicleIdentifiersAndSerialNumbersIncludingLicensePlates = VehicleIdentifiersAndSerialNumbersIncludingLicensePlates;
    }

    public String getDeviceIdentifiersAndSerialNumbers() {
        return DeviceIdentifiersAndSerialNumbers;
    }

    public void setDeviceIdentifiersAndSerialNumbers(String DeviceIdentifiersAndSerialNumbers) {
        this.DeviceIdentifiersAndSerialNumbers = DeviceIdentifiersAndSerialNumbers;
    }

    public String getLinkedIn() {
        return LinkedIn;
    }

    public void setLinkedIn(String LinkedIn) {
        this.LinkedIn = LinkedIn;
    }

    public String getInternetProtocolAddress() {
        return InternetProtocolAddress;
    }

    public void setInternetProtocolAddress(String InternetProtocolAddress) {
        this.InternetProtocolAddress = InternetProtocolAddress;
    }

    public String getUnique_ID_Char_Code() {
        return Unique_ID_Char_Code;
    }

    public void setUnique_ID_Char_Code(String Unique_ID_Char_Code) {
        this.Unique_ID_Char_Code = Unique_ID_Char_Code;
    }

    public String getBiometricIdentfiers() {
        return BiometricIdentfiers;
    }

    public void setBiometricIdentfiers(String BiometricIdentfiers) {
        this.BiometricIdentfiers = BiometricIdentfiers;
    }

    public String getPhoto() {
        return Photo;
    }

    public void setPhoto(String Photo) {
        this.Photo = Photo;
    }
    public String getDateOfBirth() {
        return DateOfBirth;
    }

    public void setDateOfBirth(String DateOfBirth) {
        this.DateOfBirth = DateOfBirth;
    }
   
}
