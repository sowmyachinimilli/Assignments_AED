/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MediCare;

/**
 *
 * @author sowmyachinimilli
 */
public class Patient extends Person{
    int VisitCount;
    String LastVisit;
    boolean AbTemp;
    boolean AbWt;
    boolean AbBP;
    boolean AbResp;

    public boolean isAbWt() {
        return AbWt;
    }

    public void setAbWt(boolean AbWt) {
        this.AbWt = AbWt;
    }

    public boolean isAbBP() {
        return AbBP;
    }

    public void setAbBP(boolean AbBP) {
        this.AbBP = AbBP;
    }

    public boolean isAbResp() {
        return AbResp;
    }

    public void setAbResp(boolean AbResp) {
        this.AbResp = AbResp;
    }
    
    public boolean isAbTemp() {
        return AbTemp;
    }

    public void setAbTemp(boolean AbTemp) {
        this.AbTemp = AbTemp;
    }
    
    public int getVisitCount() {
        return VisitCount;
    }

    public void setVisitCount(int VisitCount) {
        this.VisitCount = VisitCount;
    }

    public String getLastVisit() {
        return LastVisit;
    }

    public void setLastVisit(String LastVisit) {
        this.LastVisit = LastVisit;
    }
    
}
