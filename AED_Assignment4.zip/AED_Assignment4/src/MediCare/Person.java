/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MediCare;

/**
 *
 * @author sowmyachinimilli
 */
public class Person {
    int Pid;
    String PName;
    String DOB;
    int Age;
    String Gender;
    Community com;
    long ContactNo;

    public long getContactNo() {
        return ContactNo;
    }

    public void setContactNo(long ContactNo) {
        this.ContactNo = ContactNo;
    }
    
    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }    
    public int getPid() {
        return Pid;
    }

    public void setPid(int Pid) {
        this.Pid = Pid;
    }
    
    @Override
    public String toString(){
        return String.valueOf(Pid);
    }

    public String getPName() {
        return PName;
    }

    public void setPName(String PName) {
        this.PName = PName;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public Community getCom() {
        return com;
    }

    public void setCom(Community com) {
        this.com = com;
    }
    
}
