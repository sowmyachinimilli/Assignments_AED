/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MediCare;

/**
 *
 * @author sowmyachinimilli
 */
public class MediSystem {
    public PersonDirectory perD;
    public EncounterHistory encH;
    public PatientDirectory patD;
    public MediSystem(){
        perD = new PersonDirectory();
        encH = new EncounterHistory();
        patD =  new PatientDirectory();
    }
}
