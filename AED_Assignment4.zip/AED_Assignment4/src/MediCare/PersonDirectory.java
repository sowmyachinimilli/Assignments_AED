/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MediCare;

import java.util.ArrayList;

/**
 *
 * @author sowmyachinimilli
 */
public class PersonDirectory {
    
    public ArrayList<Person> PList;
    
    public PersonDirectory(){
        this.PList=new ArrayList<Person>();      
    }
    
    public ArrayList<Person> getPList() {
        return PList;
    }
    public void setPList(ArrayList<Person> PList) {
        this.PList = PList;
    }

    public Person addNewPerson() {
        Person newP = new Person();
        PList.add(newP);
        return newP;
    }

    public void deleteCab(Person selectedPerson) {
        PList.remove(selectedPerson);
    }
    public boolean CheckId(int chk){
        ArrayList<Person> PerList= getPList();
        for(Person p: PerList){
            if(p.getPid()==chk){
                return true;
            }
        }
        return false;
    }
}
